COP4610-Proj2
=============

This is for Part I&II of Project 2 in COP4610 at FSU Fall 2014. This project has a warning on line 17. 
